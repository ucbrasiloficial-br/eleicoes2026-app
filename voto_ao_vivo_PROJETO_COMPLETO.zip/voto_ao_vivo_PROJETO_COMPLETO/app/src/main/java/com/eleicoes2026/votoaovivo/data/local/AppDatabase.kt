package com.eleicoes2026.votoaovivo.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.eleicoes2026.votoaovivo.data.model.Candidate

@Database(entities = [Candidate::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun candidateDao(): CandidateDao
}