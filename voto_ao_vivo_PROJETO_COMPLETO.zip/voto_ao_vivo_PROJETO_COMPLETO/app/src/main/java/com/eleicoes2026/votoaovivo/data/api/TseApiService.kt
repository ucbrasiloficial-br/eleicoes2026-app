package com.eleicoes2026.votoaovivo.data.api

import com.eleicoes2026.votoaovivo.data.model.Candidate
import retrofit2.http.GET
import retrofit2.http.Path

interface TseApiService {
    // Endpoint oficial do TSE para dados reais da Eleição 2026
    @GET("resultados/2026/{uf}/dados-{role}.json")
    suspend fun getElectionData(
        @Path("uf") uf: String,
        @Path("role") role: String
    ): List<Candidate>
}