package com.eleicoes2026.votoaovivo.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.eleicoes2026.votoaovivo.presentation.components.CandidateCard
import com.eleicoes2026.votoaovivo.presentation.viewmodel.ElectionViewModel

@Composable
fun FavoritesScreen(
    viewModel: ElectionViewModel,
    onCandidateClick: (String) -> Unit
) {
    val favorites by viewModel.favoriteCandidates.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Meus Favoritos", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(12.dp))

        if (favorites.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Você ainda não possui candidatos favoritos.
Toque na ⭐ para salvar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn {
                items(favorites) { candidate ->
                    CandidateCard(
                        candidate = candidate,
                        onFavoriteClick = { viewModel.toggleFavorite(candidate.id, candidate.isFavorite) },
                        onClick = { onCandidateClick(candidate.id) }
                    )
                }
            }
        }
    }
}