package com.eleicoes2026.votoaovivo.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eleicoes2026.votoaovivo.presentation.components.CandidateCard
import com.eleicoes2026.votoaovivo.presentation.components.LiveHeader
import com.eleicoes2026.votoaovivo.presentation.viewmodel.ElectionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: ElectionViewModel,
    onCandidateClick: (String) -> Unit
) {
    val candidates by viewModel.candidates.collectAsState()
    val summary by viewModel.summary.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("VOTO AO VIVO", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Eleições Gerais 2026", fontSize = 12.sp)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refreshData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Atualizar")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            LiveHeader(lastUpdate = summary.lastUpdate)
            Spacer(modifier = Modifier.height(12.dp))

            Text("Presidente da República", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn {
                items(candidates.filter { it.role == "Presidente" }) { candidate ->
                    CandidateCard(
                        candidate = candidate,
                        onFavoriteClick = { viewModel.toggleFavorite(candidate.id, candidate.isFavorite) },
                        onClick = { onCandidateClick(candidate.id) }
                    )
                }
            }
        }
    }
}