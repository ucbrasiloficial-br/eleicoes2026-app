package com.eleicoes2026.votoaovivo.data.local

import androidx.room.*
import com.eleicoes2026.votoaovivo.data.model.Candidate
import kotlinx.coroutines.flow.Flow

@Dao
interface CandidateDao {
    @Query("SELECT * FROM candidates")
    fun getAllCandidates(): Flow<List<Candidate>>

    @Query("SELECT * FROM candidates WHERE isFavorite = 1")
    fun getFavoriteCandidates(): Flow<List<Candidate>>

    @Query("SELECT * FROM candidates WHERE id = :id")
    suspend fun getCandidateById(id: String): Candidate?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(candidates: List<Candidate>)

    @Query("UPDATE candidates SET isFavorite = :isFav WHERE id = :id")
    suspend fun updateFavorite(id: String, isFav: Boolean)
}