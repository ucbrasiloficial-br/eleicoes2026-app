package com.eleicoes2026.votoaovivo.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.eleicoes2026.votoaovivo.presentation.screens.*
import com.eleicoes2026.votoaovivo.presentation.viewmodel.ElectionViewModel

@Composable
fun MainAppNavigation(viewModel: ElectionViewModel) {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                NavigationBarItem(
                    selected = currentRoute == "home",
                    onClick = { navController.navigate("home") },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text("Início") }
                )
                NavigationBarItem(
                    selected = currentRoute == "search",
                    onClick = { navController.navigate("search") },
                    icon = { Icon(Icons.Default.Search, contentDescription = null) },
                    label = { Text("Pesquisar") }
                )
                NavigationBarItem(
                    selected = currentRoute == "favorites",
                    onClick = { navController.navigate("favorites") },
                    icon = { Icon(Icons.Default.Star, contentDescription = null) },
                    label = { Text("Favoritos") }
                )
                NavigationBarItem(
                    selected = currentRoute == "results",
                    onClick = { navController.navigate("results") },
                    icon = { Icon(Icons.Default.BarChart, contentDescription = null) },
                    label = { Text("Resultados") }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") {
                HomeScreen(viewModel = viewModel, onCandidateClick = { id ->
                    navController.navigate("profile/$id")
                })
            }
            composable("search") {
                SearchScreen(viewModel = viewModel, onCandidateClick = { id ->
                    navController.navigate("profile/$id")
                })
            }
            composable("favorites") {
                FavoritesScreen(viewModel = viewModel, onCandidateClick = { id ->
                    navController.navigate("profile/$id")
                })
            }
            composable("results") {
                DetailedResultsScreen(viewModel = viewModel)
            }
            composable(
                "profile/{candidateId}",
                arguments = listOf(navArgument("candidateId") { type = NavType.StringType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getString("candidateId") ?: ""
                ProfileScreen(candidateId = id, viewModel = viewModel, onBack = { navController.popBackStack() })
            }
        }
    }
}