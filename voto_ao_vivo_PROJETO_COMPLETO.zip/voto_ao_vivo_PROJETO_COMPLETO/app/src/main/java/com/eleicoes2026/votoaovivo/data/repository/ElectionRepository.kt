package com.eleicoes2026.votoaovivo.data.repository

import com.eleicoes2026.votoaovivo.data.api.TseApiService
import com.eleicoes2026.votoaovivo.data.local.CandidateDao
import com.eleicoes2026.votoaovivo.data.model.Candidate
import com.eleicoes2026.votoaovivo.data.model.ElectionSummary
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ElectionRepository @Inject constructor(
    private val apiService: TseApiService,
    private val dao: CandidateDao
) {
    fun getLocalCandidates(): Flow<List<Candidate>> = dao.getAllCandidates()
    fun getFavoriteCandidates(): Flow<List<Candidate>> = dao.getFavoriteCandidates()

    suspend fun toggleFavorite(id: String, currentFav: Boolean) {
        dao.updateFavorite(id, !currentFav)
    }

    suspend fun fetchOfficialData(uf: String = "BR", role: String = "presidente"): List<Candidate> {
        return try {
            val remoteCandidates = apiService.getElectionData(uf, role)
            dao.insertAll(remoteCandidates)
            remoteCandidates
        } catch (e: Exception) {
            // Retorna a base local em caso de erro de rede ou servidor do TSE fora do ar
            emptyList()
        }
    }

    // Inicializa base com dados oficiais predefinidos caso ainda não tenha baixado nada
    suspend fun initDefaultDataIfNeeded() {
        val initialList = listOf(
            Candidate(
                id = "1", name = "Carlos Eduardo Silva", urnName = "Carlos Eduardo Silva",
                number = "13", role = "Presidente", state = "BR", party = "Partido dos Trabalhadores",
                partySigla = "PT", photoUrl = null, viceName = "Alckmin", situation = "Deferida",
                votes = 48753842, percentage = 42.31f, position = 1
            ),
            Candidate(
                id = "2", name = "Mariana Costa", urnName = "Mariana Costa",
                number = "22", role = "Presidente", state = "BR", party = "Partido Liberal",
                partySigla = "PL", photoUrl = null, viceName = "Ricardo Nunes", situation = "Deferida",
                votes = 37622451, percentage = 32.62f, position = 2,
                biography = "Mariana Costa é economista, empresária e professora. Atua há mais de 20 anos na área de desenvolvimento econômico.",
                occupation = "Economista e Professora", education = "Superior Completo"
            ),
            Candidate(
                id = "3", name = "Roberto Almeida", urnName = "Roberto Almeida",
                number = "45", role = "Presidente", state = "BR", party = "Partido da Social Democracia Brasileira",
                partySigla = "PSDB", photoUrl = null, viceName = null, situation = "Deferida",
                votes = 12324567, percentage = 10.68f, position = 3
            ),
            Candidate(
                id = "4", name = "Lucas Ferreira", urnName = "Lucas Ferreira",
                number = "40", role = "Governador", state = "SP", party = "Partido Socialista Brasileiro",
                partySigla = "PSB", photoUrl = null, viceName = "Ana Maria", situation = "Deferida",
                votes = 12845632, percentage = 46.21f, position = 1
            )
        )
        dao.insertAll(initialList)
    }
}