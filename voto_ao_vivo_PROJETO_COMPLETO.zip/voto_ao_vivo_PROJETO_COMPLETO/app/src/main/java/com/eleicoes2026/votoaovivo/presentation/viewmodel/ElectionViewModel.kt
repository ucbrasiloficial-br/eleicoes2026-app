package com.eleicoes2026.votoaovivo.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eleicoes2026.votoaovivo.data.model.Candidate
import com.eleicoes2026.votoaovivo.data.model.ElectionSummary
import com.eleicoes2026.votoaovivo.data.repository.ElectionRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ElectionViewModel @Inject constructor(
    private val repository: ElectionRepository
) : ViewModel() {

    val candidates: StateFlow<List<Candidate>> = repository.getLocalCandidates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteCandidates: StateFlow<List<Candidate>> = repository.getFavoriteCandidates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _summary = MutableStateFlow(ElectionSummary(role = "Presidente", state = "BR"))
    val summary: StateFlow<ElectionSummary> = _summary.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initDefaultDataIfNeeded()
            refreshData()
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun toggleFavorite(candidateId: String, currentFav: Boolean) {
        viewModelScope.launch {
            repository.toggleFavorite(candidateId, currentFav)
        }
    }

    fun refreshData() {
        viewModelScope.launch {
            repository.fetchOfficialData("BR", "presidente")
        }
    }
}