package com.eleicoes2026.votoaovivo.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.eleicoes2026.votoaovivo.presentation.components.CandidateCard
import com.eleicoes2026.votoaovivo.presentation.viewmodel.ElectionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: ElectionViewModel,
    onCandidateClick: (String) -> Unit
) {
    val query by viewModel.searchQuery.collectAsState()
    val candidates by viewModel.candidates.collectAsState()

    val filteredCandidates = candidates.filter {
        it.urnName.contains(query, ignoreCase = true) ||
        it.number.contains(query) ||
        it.partySigla.contains(query, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.onSearchQueryChanged(it) },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar candidato, número ou partido...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(filteredCandidates) { candidate ->
                CandidateCard(
                    candidate = candidate,
                    onFavoriteClick = { viewModel.toggleFavorite(candidate.id, candidate.isFavorite) },
                    onClick = { onCandidateClick(candidate.id) }
                )
            }
        }
    }
}