package com.eleicoes2026.votoaovivo.data.model

data class ElectionSummary(
    val role: String,
    val state: String,
    val totalizedPercentage: Float = 68.42f,
    val totalUrnas: Long = 180000,
    val apuradasUrnas: Long = 123456,
    val validVotes: Long = 98760369,
    val blankVotes: Long = 4321987,
    val nullVotes: Long = 2845221,
    val totalAttendance: Long = 105927577,
    val isLive: Boolean = true,
    val lastUpdate: String = "12:30:00",
    val statusText: String = "APURAÇÃO EM ANDAMENTO"
)