package com.eleicoes2026.votoaovivo.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.hilt.navigation.compose.hiltViewModel
import com.eleicoes2026.votoaovivo.presentation.navigation.MainAppNavigation
import com.eleicoes2026.votoaovivo.presentation.theme.VotoAoVivoTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VotoAoVivoTheme {
                val viewModel: com.eleicoes2026.votoaovivo.presentation.viewmodel.ElectionViewModel = hiltViewModel()
                MainAppNavigation(viewModel = viewModel)
            }
        }
    }
}