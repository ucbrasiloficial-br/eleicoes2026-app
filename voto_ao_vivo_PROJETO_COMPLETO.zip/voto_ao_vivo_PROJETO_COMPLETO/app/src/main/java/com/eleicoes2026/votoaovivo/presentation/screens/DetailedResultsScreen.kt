package com.eleicoes2026.votoaovivo.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eleicoes2026.votoaovivo.presentation.viewmodel.ElectionViewModel

@Composable
fun DetailedResultsScreen(viewModel: ElectionViewModel) {
    val summary by viewModel.summary.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Resultado Detalhado — Brasil", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(modifier = Modifier.height(16.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Totalização: ${summary.totalizedPercentage}%", fontWeight = FontWeight.Bold)
                Text("Urnas apuradas: ${summary.apuradasUrnas} / ${summary.totalUrnas}")
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = summary.totalizedPercentage / 100f,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Detalhamento de Votos", fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Votos Válidos: ${summary.validVotes}")
        Text("Votos Brancos: ${summary.blankVotes}")
        Text("Votos Nulos: ${summary.nullVotes}")
        Text("Comparecimento: ${summary.totalAttendance}")
    }
}