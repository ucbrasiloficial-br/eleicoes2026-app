package com.eleicoes2026.votoaovivo.di

import android.content.Context
import androidx.room.Room
import com.eleicoes2026.votoaovivo.data.api.TseApiService
import com.eleicoes2026.votoaovivo.data.local.AppDatabase
import com.eleicoes2026.votoaovivo.data.local.CandidateDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "voto_ao_vivo_db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    fun provideCandidateDao(db: AppDatabase): CandidateDao = db.candidateDao()

    @Provides
    @Singleton
    fun provideTseApiService(): TseApiService {
        return Retrofit.Builder()
            .baseUrl("https://resultados.tse.jus.br/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TseApiService::class.java)
    }
}