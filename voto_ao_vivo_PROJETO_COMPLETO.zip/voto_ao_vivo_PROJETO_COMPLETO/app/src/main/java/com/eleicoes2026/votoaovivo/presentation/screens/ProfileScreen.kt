package com.eleicoes2026.votoaovivo.presentation.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eleicoes2026.votoaovivo.presentation.theme.GoldAccent
import com.eleicoes2026.votoaovivo.presentation.viewmodel.ElectionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    candidateId: String,
    viewModel: ElectionViewModel,
    onBack: () -> Unit
) {
    val candidates by viewModel.candidates.collectAsState()
    val candidate = candidates.find { it.id == candidateId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Perfil do Candidato") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        candidate?.let { item ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(item.urnName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                        Text("${item.role} • Nº ${item.number}", color = GoldAccent, fontWeight = FontWeight.Bold)
                        Text("${item.partySigla} — ${item.party}", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Informações do Candidato", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(8.dp))

                Text("Situação da Candidatura: ${item.situation}")
                Text("Vice: ${item.viceName ?: "Não informado / Não aplicável"}")
                Text("Ocupação: ${item.occupation ?: "Informação não disponível"}")
                Text("Grau de Instrução: ${item.education ?: "Informação não disponível"}")

                Spacer(modifier = Modifier.height(16.dp))

                item.biography?.let { bio ->
                    Text("Biografia", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(bio)
                }
            }
        } ?: Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Candidato não encontrado.")
        }
    }
}