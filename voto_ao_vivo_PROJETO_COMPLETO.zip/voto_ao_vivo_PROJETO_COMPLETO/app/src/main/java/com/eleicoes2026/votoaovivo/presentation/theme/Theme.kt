package com.eleicoes2026.votoaovivo.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF0F172A)
val NavySecondary = Color(0xFF1E293B)
val GoldAccent = Color(0xFFEAB308)
val LiveRed = Color(0xFFEF4444)
val SuccessGreen = Color(0xFF22C55E)
val LightBackground = Color(0xFFF8FAFC)

private val DarkColorScheme = darkColorScheme(
    primary = NavyPrimary,
    secondary = GoldAccent,
    background = NavyPrimary,
    surface = NavySecondary
)

private val LightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    secondary = GoldAccent,
    background = LightBackground,
    surface = Color.White
)

@Composable
fun VotoAoVivoTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(colorScheme = colors, content = content)
}