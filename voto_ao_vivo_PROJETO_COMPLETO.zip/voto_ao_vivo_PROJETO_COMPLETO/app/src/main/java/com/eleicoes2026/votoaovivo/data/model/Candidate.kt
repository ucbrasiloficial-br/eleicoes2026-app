package com.eleicoes2026.votoaovivo.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "candidates")
data class Candidate(
    @PrimaryKey val id: String,
    val name: String,
    val urnName: String,
    val number: String,
    val role: String, // Presidente, Governador, Senador, etc.
    val state: String, // UF ou BR
    val party: String,
    val partySigla: String,
    val photoUrl: String?,
    val viceName: String? = null,
    val situation: String = "Candidatura Deferida",
    val votes: Long = 0,
    val percentage: Float = 0f,
    val position: Int = 0,
    val isFavorite: Boolean = false,
    val biography: String? = null,
    val occupation: String? = null,
    val education: String? = null,
    val declaredAssets: String? = null
)