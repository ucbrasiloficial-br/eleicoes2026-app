# Voto Ao Vivo — Eleições 2026

Aplicativo nativo Android construído em Kotlin e Jetpack Compose para acompanhamento das Eleições 2026 no Brasil.

## Como compilar para APK no GitHub (Sem instalar nada):

1. Crie um novo repositório público ou privado no seu GitHub.
2. Faça o upload de todos os arquivos deste ZIP para o seu repositório.
3. Vá para a aba **Actions** no seu GitHub.
4. Selecione o workflow **Build APK - Eleicoes 2026** e clique em **Run workflow**.
5. Aguarde 3-5 minutos. O GitHub compilará o aplicativo e entregará o arquivo **.apk** pronto para download na seção *Artifacts*.